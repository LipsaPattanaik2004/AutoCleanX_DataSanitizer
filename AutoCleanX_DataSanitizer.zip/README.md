# AutoCleanX

Automated data cleaning and validation tool. The notebook `autocleanx_notebook.ipynb` demonstrates
how to use the library functions. `autoclean.py` contains reusable functions for cleaning, validation
and basic reporting. Place `raw_data.csv` in the `data/` folder.

Key features:
- Missing value detection & imputation
- Email and data format validation
- Outlier detection
- Automated summary report generation

Tech: Python, Pandas, Regex, CSV
